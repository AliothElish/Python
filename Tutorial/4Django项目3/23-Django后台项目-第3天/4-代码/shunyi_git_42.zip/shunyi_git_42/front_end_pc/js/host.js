// 保存后端API服务器地址
 var host = 'http://www.meiduo.site:8000';
//var host = 'http://127.0.0.1:8000';
