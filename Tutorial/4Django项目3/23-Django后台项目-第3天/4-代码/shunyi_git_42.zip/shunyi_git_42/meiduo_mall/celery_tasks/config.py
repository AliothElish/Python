# 配置信息 key=value
# 我们指定 redis为我们的broker(中间人，经纪人，队列)
broker_url="redis://127.0.0.1:6379/15"