"""
项目1：        ＨＴＭＬ页面我们称之为　门户网址　或者　用户端     www.meiduo.site:8080
项目1:         Django 进行后台的支持                        www.meiduo.site:8000


项目2:        Vue-HTML 页面 我们称之为 美多商城后台的前端页面   www.meiduo.site:8080
项目2:        Django-DRF 进行后台支持的 美多商城后台的后台     www.meiduo.site:8000


##################################################################
项目1：        ＨＴＭＬ页面我们称之为　门户网址　或者　用户端     www.meiduo.site:8090
项目2:        Vue-HTML 页面 我们称之为 美多商城后台的前端页面   www.meiduo.site:8080
项目:        Django-DRF 进行后台支持的 美多商城后台          www.meiduo.site:8000

"""