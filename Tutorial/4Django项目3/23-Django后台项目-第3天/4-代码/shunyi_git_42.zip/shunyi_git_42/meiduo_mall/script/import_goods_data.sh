#!/bin/bash
mysql -uroot -pmysql meiduo_mall_42 < goods_data.sql
